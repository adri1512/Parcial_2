import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:preferenciauser/src/Share_prefs/preferencia_usuario.dart';
import 'package:preferenciauser/src/widget/menu_widget.dart';
import 'package:table_calendar/table_calendar.dart';

class Appointment extends StatefulWidget {
  static const String routeName = 'Citas';

  const Appointment({super.key});

  @override
  State<Appointment> createState() => _AppointmentState();
}

class _AppointmentState extends State<Appointment> {
  final prefs = PreferenciasUsuario();
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    prefs.ultimapagina = Appointment.routeName;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Color.fromRGBO(65, 70, 89, 1),
      appBar: AppBar(
        // The title text which will be shown on the action bar
        title: Text('Citas'),
        backgroundColor: Color.fromRGBO(65, 70, 89, 1),
        elevation: 0,
      ),
      drawer: MenuWidget(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.fromLTRB(20, 50, 0, 0),
            child: Text(
              "Agenda",
              style: TextStyle(
                  fontSize: 31.0,
                  fontWeight: FontWeight.w400,
                  color: Colors.white),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(20, 0, 0, 10),
            child: Text(
              "BarberShop",
              style: TextStyle(
                  fontSize: 30.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
          ),
          Container(
            width: 300,
            height: 1,
            margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
            color: Colors.white,
          ),
          Column(
            children: [
              TableCalendar(
                firstDay: DateTime.utc(2023, 1, 1),
                lastDay: DateTime.utc(2023, 12, 31),
                focusedDay: _focusedDay,
                calendarFormat: _calendarFormat,
                selectedDayPredicate: (day) {
                  return isSameDay(_selectedDay, day);
                },
                onDaySelected: (selectedDay, focusedDay) {
                  setState(() {
                    _selectedDay = selectedDay;
                    _focusedDay = focusedDay;
                  });
                },
                onFormatChanged: (format) {
                  setState(() {
                    _calendarFormat = format;
                  });
                },
              ),
              ElevatedButton(
                child: Text(
                  "Realizar Cita",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  primary: Color.fromRGBO(
                      28, 32, 41, 1), // Cambia el color de fondo del botón
                  onPrimary: Color.fromRGBO(
                      229, 232, 225, 1), // Cambia el color del texto del botón
                  elevation: 10, // Cambia la elevación del botón
                  padding: EdgeInsets.symmetric(
                      vertical: 15,
                      horizontal: 30), // Cambia el padding del botón
                  shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(30), // Cambia la forma del botón
                  ),
                ),
                onPressed: () {
                  if (_selectedDay != null) {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: Text('Día seleccionado para la cita'),
                          content:
                              Text('Has seleccionado el día: $_selectedDay'),
                          actions: <Widget>[
                            TextButton(
                              child: Text('Cerrar'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                            TextButton(
                              child: Text('Guadar cita'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                          ],
                        );
                      },
                    );
                  }
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}
