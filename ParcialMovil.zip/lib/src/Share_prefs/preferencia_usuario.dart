import 'package:shared_preferences/shared_preferences.dart';

class PreferenciasUsuario {
/***
 * patron singlenton
 */
  late SharedPreferences _perfs;

  initPrefs() async {
    _perfs = await SharedPreferences.getInstance();
  }

  static final PreferenciasUsuario _instancia = PreferenciasUsuario._internal();

  factory PreferenciasUsuario() {
    return _instancia;
  }
  PreferenciasUsuario._internal();

  String get ultimapagina => _perfs.getString('ultimapagina') ?? "Home";

  set ultimapagina(String value) => _perfs.setString('ultimapagina', value);
}
