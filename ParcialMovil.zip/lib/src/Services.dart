import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:preferenciauser/src/Share_prefs/preferencia_usuario.dart';
import 'package:preferenciauser/src/widget/menu_widget.dart';
//import 'package:shared_preferences/shared_preferences.dart';

class Settinguser extends StatefulWidget {
  static const String routeName = 'Ajustes';

  const Settinguser({super.key});

  @override
  State<Settinguser> createState() => _SettinguserState();
}

class _SettinguserState extends State<Settinguser> {
  final prefs = PreferenciasUsuario();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    prefs.ultimapagina = Settinguser.routeName;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Color.fromRGBO(65, 70, 89, 1),
      appBar: AppBar(
        // The title text which will be shown on the action bar
        title: Text('Servicios'),
        backgroundColor: Color.fromRGBO(65, 70, 89, 1),
        elevation: 0,
      ),
      drawer: MenuWidget(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.fromLTRB(20, 50, 0, 0),
            child: Text(
              "Saludos,",
              style: TextStyle(
                  fontSize: 31.0,
                  fontWeight: FontWeight.w400,
                  color: Colors.white),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(20, 0, 0, 10),
            child: Text(
              "BarberShop",
              style: TextStyle(
                  fontSize: 30.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
          ),
          Container(
            width: 300,
            height: 1,
            margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
            color: Colors.white,
          ),
          Container(
            margin: EdgeInsets.fromLTRB(20, 10, 0, 10),
            child: Text(
              "Servicios",
              style: TextStyle(
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
          ),
          Row(
            children: [
              Container(
                width: 145,
                height: 145,
                margin: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 20.0),
                decoration: BoxDecoration(
                  color: Color.fromRGBO(28, 32, 41, 1),
                  borderRadius: BorderRadiusDirectional.only(
                    topStart: Radius.circular(10.0),
                    topEnd: Radius.circular(20.0),
                    bottomStart: Radius.circular(30.0),
                    bottomEnd: Radius.circular(0.0),
                  ),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      top: 10,
                      left: 15,
                      child: Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                        ),
                        child: Image(image: AssetImage('assets/img/corte.png')),
                      ),
                    ),
                    Positioned(
                      bottom: 15,
                      left: 15,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Corte de cabello',
                            style: TextStyle(
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          ),
                          Text(
                            '\$ 12.000',
                            style: TextStyle(
                                fontSize: 15.0,
                                fontWeight: FontWeight.w400,
                                color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 145,
                height: 145,
                margin: EdgeInsets.fromLTRB(0.0, 0.0, 20.0, 20.0),
                decoration: BoxDecoration(
                  color: Color.fromRGBO(28, 32, 41, 1),
                  borderRadius: BorderRadiusDirectional.only(
                    topStart: Radius.circular(10.0),
                    topEnd: Radius.circular(20.0),
                    bottomStart: Radius.circular(30.0),
                    bottomEnd: Radius.circular(0.0),
                  ),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      top: 10,
                      left: 15,
                      child: Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                        ),
                        child: Image(
                            image: AssetImage('assets/img/corte_barba.png')),
                      ),
                    ),
                    Positioned(
                      bottom: 15,
                      left: 15,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Recorte de barba',
                            style: TextStyle(
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          ),
                          Text(
                            '\$ 8.000',
                            style: TextStyle(
                                fontSize: 15.0,
                                fontWeight: FontWeight.w400,
                                color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          Row(
            children: [
              Container(
                width: 145,
                height: 145,
                margin: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 20.0),
                decoration: BoxDecoration(
                  color: Color.fromRGBO(28, 32, 41, 1),
                  borderRadius: BorderRadiusDirectional.only(
                    topStart: Radius.circular(10.0),
                    topEnd: Radius.circular(20.0),
                    bottomStart: Radius.circular(30.0),
                    bottomEnd: Radius.circular(0.0),
                  ),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      top: 10,
                      left: 15,
                      child: Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                        ),
                        child:
                            Image(image: AssetImage('assets/img/limpieza.png')),
                      ),
                    ),
                    Positioned(
                      bottom: 15,
                      left: 15,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Limpieza general',
                            style: TextStyle(
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          ),
                          Text(
                            '\$ 45.600',
                            style: TextStyle(
                                fontSize: 15.0,
                                fontWeight: FontWeight.w400,
                                color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 145,
                height: 145,
                margin: EdgeInsets.fromLTRB(0.0, 0.0, 20.0, 20.0),
                decoration: BoxDecoration(
                  color: Color.fromRGBO(28, 32, 41, 1),
                  borderRadius: BorderRadiusDirectional.only(
                    topStart: Radius.circular(10.0),
                    topEnd: Radius.circular(20.0),
                    bottomStart: Radius.circular(30.0),
                    bottomEnd: Radius.circular(0.0),
                  ),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      top: 10,
                      left: 15,
                      child: Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                        ),
                        child:
                            Image(image: AssetImage('assets/img/secador.png')),
                      ),
                    ),
                    Positioned(
                      bottom: 15,
                      left: 15,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Cambio de look',
                            style: TextStyle(
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          ),
                          Text(
                            '\$ 51.300',
                            style: TextStyle(
                                fontSize: 15.0,
                                fontWeight: FontWeight.w400,
                                color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          Container(
            width: 315,
            height: 80,
            margin: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 20.0),
            padding: EdgeInsets.all(5),
            decoration: BoxDecoration(
              color: Color.fromRGBO(28, 32, 41, 1),
              borderRadius: BorderRadiusDirectional.only(
                topStart: Radius.circular(10.0),
                topEnd: Radius.circular(20.0),
                bottomStart: Radius.circular(30.0),
                bottomEnd: Radius.circular(0.0),
              ),
            ),
            child: Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Nuestros servicios son de alta calidad',
                    style: TextStyle(
                        fontSize: 15.0,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  Text(
                    'Contamos con personal experto',
                    style: TextStyle(
                        fontSize: 15.0,
                        fontWeight: FontWeight.w400,
                        color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
