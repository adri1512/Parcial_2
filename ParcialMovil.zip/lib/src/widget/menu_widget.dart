import 'package:flutter/material.dart';
import 'package:preferenciauser/src/MyHomePage.dart';
import 'package:preferenciauser/src/Services.dart';

import '../Appointment.dart';
import '../Barbers.dart';

class MenuWidget extends StatelessWidget {
  const MenuWidget({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Container(
            width: 20,
            height: 1,
            margin: EdgeInsets.fromLTRB(20, 10, 20, 10),
            color: Color.fromRGBO(36, 68, 127, 1),
          ),
          DrawerHeader(
            child: Container(),
            decoration: BoxDecoration(
                image: DecorationImage(
              image: AssetImage('assets/img/barber.png'),
            )),
          ),
          Container(
            width: 20,
            height: 1,
            margin: EdgeInsets.fromLTRB(20, 10, 20, 10),
            color: Color.fromRGBO(36, 68, 127, 1),
          ),
          ListTile(
            leading: Image(image: AssetImage('assets/img/hogar.png')),
            title: Text('Inicio'),
            onTap: () {
              Navigator.pushReplacementNamed(context, MyHomePage.routeName);
            },
          ),
          ListTile(
            leading: Image(image: AssetImage('assets/img/configuracion.png')),
            title: Text('Servicios'),
            onTap: () {
              Navigator.pushReplacementNamed(context, Settinguser.routeName);
            },
          ),
          ListTile(
            leading: Image(image: AssetImage('assets/img/usuario.png')),
            title: Text('Barberos'),
            onTap: () {
              Navigator.pushReplacementNamed(context, Barbers.routeName);
            },
          ),
          ListTile(
            leading: Image(image: AssetImage('assets/img/agenda.png')),
            title: Text('Agenda tu cita'),
            onTap: () {
              Navigator.pushReplacementNamed(context, Appointment.routeName);
            },
          ),
        ],
      ),
    );
  }
}
