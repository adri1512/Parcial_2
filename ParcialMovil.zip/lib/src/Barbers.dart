import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:preferenciauser/src/Share_prefs/preferencia_usuario.dart';
import 'package:preferenciauser/src/widget/menu_widget.dart';
//import 'package:shared_preferences/shared_preferences.dart';

class Barbers extends StatefulWidget {
  static const String routeName = 'Barberos';

  const Barbers({super.key});

  @override
  State<Barbers> createState() => _BarbersState();
}

class _BarbersState extends State<Barbers> {
  final prefs = PreferenciasUsuario();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    prefs.ultimapagina = Barbers.routeName;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: Color.fromRGBO(65, 70, 89, 1),
      appBar: AppBar(
        // The title text which will be shown on the action bar
        title: Text('Barberos'),
        backgroundColor: Color.fromRGBO(65, 70, 89, 1),
        elevation: 0,
      ),
      drawer: MenuWidget(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.fromLTRB(20, 50, 0, 0),
            child: Text(
              "Personal",
              style: TextStyle(
                  fontSize: 31.0,
                  fontWeight: FontWeight.w400,
                  color: Colors.white),
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(20, 0, 0, 10),
            child: Text(
              "BarberShop",
              style: TextStyle(
                  fontSize: 30.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
          ),
          Container(
            width: 300,
            height: 1,
            margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
            color: Colors.white,
          ),
          Container(
            width: 315,
            height: 80,
            margin: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 20.0),
            padding: EdgeInsets.all(5),
            decoration: BoxDecoration(
              color: Color.fromRGBO(28, 32, 41, 1),
              borderRadius: BorderRadiusDirectional.only(
                topStart: Radius.circular(10.0),
                topEnd: Radius.circular(20.0),
                bottomStart: Radius.circular(30.0),
                bottomEnd: Radius.circular(0.0),
              ),
            ),
            child: Center(
              child: Image(image: AssetImage('assets/img/personal.png')),
            ),
          ),
          Row(
            children: [
              Container(
                width: 145,
                height: 145,
                margin: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 20.0),
                decoration: BoxDecoration(
                  color: Color.fromRGBO(28, 32, 41, 1),
                  borderRadius: BorderRadiusDirectional.only(
                    topStart: Radius.circular(10.0),
                    topEnd: Radius.circular(20.0),
                    bottomStart: Radius.circular(30.0),
                    bottomEnd: Radius.circular(0.0),
                  ),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      top: 10,
                      left: 20,
                      child:
                          Image(image: AssetImage('assets/img/barbero1.png')),
                    ),
                    Positioned(
                      bottom: 15,
                      left: 15,
                      child: Text(
                        'Ricardo F',
                        style: TextStyle(
                            fontSize: 15.0,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 145,
                height: 145,
                margin: EdgeInsets.fromLTRB(0.0, 0.0, 20.0, 20.0),
                decoration: BoxDecoration(
                  color: Color.fromRGBO(28, 32, 41, 1),
                  borderRadius: BorderRadiusDirectional.only(
                    topStart: Radius.circular(10.0),
                    topEnd: Radius.circular(20.0),
                    bottomStart: Radius.circular(30.0),
                    bottomEnd: Radius.circular(0.0),
                  ),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      top: 10,
                      left: 20,
                      child:
                          Image(image: AssetImage('assets/img/barbero2.png')),
                    ),
                    Positioned(
                      bottom: 15,
                      left: 15,
                      child: Text(
                        'Emanuel G',
                        style: TextStyle(
                            fontSize: 15.0,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          Row(
            children: [
              Container(
                width: 145,
                height: 145,
                margin: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 20.0),
                decoration: BoxDecoration(
                  color: Color.fromRGBO(28, 32, 41, 1),
                  borderRadius: BorderRadiusDirectional.only(
                    topStart: Radius.circular(10.0),
                    topEnd: Radius.circular(20.0),
                    bottomStart: Radius.circular(30.0),
                    bottomEnd: Radius.circular(0.0),
                  ),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      top: 10,
                      left: 20,
                      child:
                          Image(image: AssetImage('assets/img/barbero3.png')),
                    ),
                    Positioned(
                      bottom: 15,
                      left: 15,
                      child: Text(
                        'Maria Q',
                        style: TextStyle(
                            fontSize: 15.0,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 145,
                height: 145,
                margin: EdgeInsets.fromLTRB(0.0, 0.0, 20.0, 20.0),
                decoration: BoxDecoration(
                  color: Color.fromRGBO(28, 32, 41, 1),
                  borderRadius: BorderRadiusDirectional.only(
                    topStart: Radius.circular(10.0),
                    topEnd: Radius.circular(20.0),
                    bottomStart: Radius.circular(30.0),
                    bottomEnd: Radius.circular(0.0),
                  ),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      top: 10,
                      left: 20,
                      child:
                          Image(image: AssetImage('assets/img/barbero4.png')),
                    ),
                    Positioned(
                      bottom: 15,
                      left: 15,
                      child: Text(
                        'Adrian N',
                        style: TextStyle(
                            fontSize: 15.0,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
