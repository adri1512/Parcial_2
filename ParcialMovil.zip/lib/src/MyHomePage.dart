import 'package:flutter/material.dart';
import 'package:preferenciauser/src/Share_prefs/preferencia_usuario.dart';
import 'package:preferenciauser/src/Services.dart';
import 'package:preferenciauser/src/widget/menu_widget.dart';

class MyHomePage extends StatelessWidget {
  static const String routeName = 'Home';

  const MyHomePage({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    final prefs = PreferenciasUsuario();
    prefs.ultimapagina = routeName;
    return Scaffold(
        backgroundColor: Color.fromRGBO(65, 70, 89, 1),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              width: 300,
              height: 1,
              margin: EdgeInsets.fromLTRB(30, 50, 30, 10),
              color: Colors.white,
            ),
            Text(
              "BIENVENIDOS",
              style: TextStyle(
                  fontSize: 31.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
            Text(
              "BARBERSHOP",
              style: TextStyle(
                  fontSize: 50.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
            ),
            Container(
              width: 300,
              height: 1,
              margin: EdgeInsets.fromLTRB(30, 10, 30, 10),
              color: Colors.white,
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 0, 0, 30),
              child: Image(
                image: AssetImage('assets/img/peinado.png'),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
              child: Text(
                "la elegancia y el cuidado van de la mano",
                style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.w400,
                    color: Colors.white),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 0, 0, 30),
              child: Text(
                "transforma tu estilo",
                style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.w400,
                    color: Colors.white),
              ),
            ),
            ElevatedButton(
              child: Text(
                "Conócenos",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              style: ElevatedButton.styleFrom(
                primary: Color.fromRGBO(
                    28, 32, 41, 1), // Cambia el color de fondo del botón
                onPrimary: Color.fromRGBO(
                    229, 232, 225, 1), // Cambia el color del texto del botón
                elevation: 10, // Cambia la elevación del botón
                padding: EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 30), // Cambia el padding del botón
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(30), // Cambia la forma del botón
                ),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Settinguser(),
                  ),
                );
              },
            ),
          ],
        ));
  }
}
